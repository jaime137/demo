package com.example.gestionpartidospadel.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Entity
public class Partido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private Long id;

    private String fecha; 

    private String ubicacion; 

    @Enumerated(EnumType.STRING) 
    private Estado estado;

    
    public Partido() {}

    
    public Partido(String fecha, String ubicacion, Estado estado) {
        this.fecha = fecha;
        this.ubicacion = ubicacion;
        this.estado = estado;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    
    public enum Estado {
        PROGRAMADO,
        EN_CURSO,
        FINALIZADO
    }
}
