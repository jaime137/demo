package com.ejemplo.controller;

import com.ejemplo.model.Partido;
import com.ejemplo.service.PartidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/partidos")
public class PartidoController {

    @Autowired
    private PartidoService partidoService;

    // Listar todos los partidos
    @GetMapping
    public String listarPartidos(Model model) {
        model.addAttribute("partidos", partidoService.obtenerTodosPartidos());
        return "partidos/listar";  // Vista de listar partidos
    }

    // Mostrar formulario para crear un nuevo partido
    @GetMapping("/crear")
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("partido", new Partido());
        return "partidos/crear";  // Vista de formulario de creación
    }

    // Guardar un nuevo partido
    @PostMapping
    public String guardarPartido(@ModelAttribute Partido partido) {
        partidoService.guardarPartido(partido);
        return "redirect:/partidos";  // Redirige a la lista de partidos
    }

    // Mostrar detalles de un partido
    @GetMapping("/{id}")
    public String verPartido(@PathVariable Long id, Model model) {
        model.addAttribute("partido", partidoService.obtenerPartidoPorId(id));
        return "partidos/ver";  // Vista de detalles de un partido
    }

    // Eliminar un partido
    @GetMapping("/eliminar/{id}")
    public String eliminarPartido(@PathVariable Long id) {
        partidoService.eliminarPartido(id);
        return "redirect:/partidos";  // Redirige a la lista de partidos
    }

    // Mostrar formulario para editar un partido
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        model.addAttribute("partido", partidoService.obtenerPartidoPorId(id));
        return "partidos/editar";  // Vista de formulario de edición
    }

    // Guardar los cambios de un partido editado
    @PostMapping("/editar/{id}")
    public String editarPartido(@PathVariable Long id, @ModelAttribute Partido partido) {
        partido.setId(id);
        partidoService.guardarPartido(partido);
        return "redirect:/partidos";
    }
}
