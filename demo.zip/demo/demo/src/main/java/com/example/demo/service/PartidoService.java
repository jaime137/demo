package com.ejemplo.service;

import com.ejemplo.model.Partido;
import com.ejemplo.repository.PartidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PartidoService {

    @Autowired
    private PartidoRepository partidoRepository;

    public List<Partido> obtenerTodosPartidos() {
        return partidoRepository.findAll();
    }

    public Partido obtenerPartidoPorId(Long id) {
        Optional<Partido> partido = partidoRepository.findById(id);
        return partido.orElse(null);
    }

    public void guardarPartido(Partido partido) {
        partidoRepository.save(partido);
    }

    public void eliminarPartido(Long id) {
        partidoRepository.deleteById(id);
    }
}
